# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   BWarn
# Date:  May 4, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   BWarn, 0504/2017 Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# This program manages a ToDo list.  The ToDo file will contain two columns of data (Task, Priority) which will be stored in a Python dictionary.
# Each Dictionary will represent one row of data. The row of data will then be added to a Python List to create a table of data.

# -- Data --#
# declare variables and constants
# Initialize the dictionary and the list:
myDict = {}
myList = []

# -- Input/Output --#
# Step 1. When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)

# -- Processing --#
# Open file for reading:
text_file = open("ToDo.txt", "r")
# Use a for loop to read a single line of text from the file and then place the data into a new dictionary object. Use strip() and split() to remove whitespace and divide contents into separate entries that are then read into the myDict dictionary.
for line in text_file:
    x = line.strip().split(",")
    task_key = x[0]
    task_priority = x[1]
    myDict[task_key] = task_priority
text_file.close()

# Step 2. Display the contents of the list to the user.
# Note: The actual display action occurs inside the "if (strChoice.strip() == '1'" section.
# The code from here to that point needs to be performed to enable the "if (strChoice.strip() == '1'" section to work correctly.

# After putting the data in a Python dictionary, add the new dictionary “row” into a Python list object (now the data will be managed as a table).
# Step 2. Display the contents of the list to the user.
print("Your list is:")
print("Task\t\tPriority\n", end='')
print("----\t\t--------\n", end='')
for key, value in myDict.items():
    myList.append([key, value])
    print(key, "\t", value, "\n", end='')

# Use a menu to add or removes from the list using numbered choices.
# Display the menu and prompt for initial input.  Note that ‘while True’ indicates this loop will continue “forever”.  It only ends with the ‘break’ statement in a later ‘if’ (‘elif’ actually) statement.

while True:
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    if (strChoice.strip() == '1'):
        print("Your list is:")
        print("Task\t\tPriority\n", end='')
        print("----\t\t--------\n", end='')
        for row in myList:
            print(row[0],"\t",row[1])
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        key = str(input("Please enter the type of task you want to add: "))
        value = str(input("Please enter the priority of your task (low,medium,high): ").lower())
        entry = [key, value]
        myList.append(entry)
        print(key, ":", value, " has been added to your list.")
        continue
    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        key = str(input("Please enter the type of task you want to delete: "))
        # To remove from list, determine the index that corresponds to the task.  Remove the task and then remove the list entry that exists to the right (i.e. the value)
        #print ("myList is", myList)
        i=0
        for item in myList:
            # Leaving the following three print statements if needed for future debugging purposes.
            #print("\n\nmyList",i," is: ",myList[i])
            #print("item is: ",item)
            #print("key is: ",key)
            if key in item[0]:
                # KNOWN BUG HERE: if any part of item[0] is in key, then myList[i] will be deleted in the next step. Not fixing this bug now but may later if future class assignments produce the need to do so.  Program works fine if entire task type phrase is entered.
                myList.remove(myList[i])
                print(key, "has been deleted from your task list.")
                #print("myList is now: ",myList)
            else:
                print("Cannot remove", key, "since that task type does not exist in your list")
            i+=1
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        save = str(input("Do you want to save the data (y or n)? ")).lower()
        if save == 'y':
            text_file = open("ToDo.txt", "w")
            i = 0  # Used to determine if for item in row is at the end of a row.  If yes, then add a newline.
            for row in myList:
                for item in row:
                    if i % 2 == 0:
                        text_file.write(str(item) + ",")
                    else:
                        text_file.write(str(item) + "\n")
                    i += 1
            text_file.close()
            print("\nData has been saved.")
        else:
            print("Your list was not saved to text.")
        continue
    elif (strChoice == '5'):
        break  # and Exit the program
