
#-------------------------------------------------#
# Title: Working with Classes and Functions
# Dev:   BWarn
# Date:  May 05, 2017
# ChangeLog: (Who, When, What)
#   BWarn, 2017-05-08, Initial release. Place code for five operations, show current data, add a new item, remove an existing item, save data to file, and exit program, into functions and a class.
# http://www.tutorialspoint.com/python/python_functions.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# textFileName = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove an item from the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------
textFileName = 'ToDo.txt'
strData = ""
dicRow = {}
lstTable = []
lstOccurrence = []

class Tasklist(object):
    # A collection of operations on a Python list

    def print_statement(strChoice):
        print ("This is choice", strChoice)

    def show_menu(object):
        # show the list's contents
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
    def show_contents(list):
        # method to show contents in the table
        # .format() used to make list contents more readable.
        print("The current items ToDo are:")
        print("Task\t\t\t  Priority")
        print("*************\t\t  *********")
        for row in list:
            print("{0:<25s} {1:<15s}".format(row["Task"], row["Priority"]))
            # format says for row["Task'], the 0th variable, align left and make 25 spaces wide. Make the 1st term, row["Priority"], 15 spaces wide and align the text to the left.
        print("***********************************")



    def add_item(object):
        # method to add entry to list
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|medium|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        Tasklist.show_contents(lstTable) # show the list again after new task added to it.


    def remove_item(list):
        # method to remove item from list
        Tasklist.show_contents(list) # show the list prior to removing the item.
        strKeyToRemove = input("Which task do you want to remove from the list? ").strip()
        intOccurrence = 0
        for row in list:
            if strKeyToRemove in row["Task"]:
                # strKeyToRemove was found and removed.
                print(strKeyToRemove,"was removed from the task list.")
                list.remove(row)
                lstOccurrence.append("1") # Record that something was found.  If nothing was found, report in a later step.
            else:
                # Note: Can't report here that nothing was found since the program will print a 'not found' statement for every 'not found' row in the list.
                None
        if len(lstOccurrence) <1:
            # Reports that strKeyToRemove wasn't found anywhere in the list.
            print(strKeyToRemove,"not found in list.")

    def save_data(list):
        # method to write data to disk
        save_file=input("Do you want to save the data to disk (y or n)? ").lower()
        if save_file == 'y':
            text_file=open(textFileName,"w")
            for dicRow in list:
                text_file.write(dicRow["Task"]+","+dicRow["Priority"]+"\n")
            text_file.close()
            print("Data was saved to",textFileName)
        else:
            print("Data was not saved.")

# -- Processing --#
# Step 1
# Open file for reading:

def main():
    # main is important because it avoids accidentally creating global variables that could affect other functions. main is also important to enable the code to be called elsewhere with 'import <module name>'.

    text_file = open(textFileName, "r")
    # Use a for loop to read a single line of text from the file and then place the data into a new dictionary object. Use strip() and split() to remove whitespace and divide contents into separate entries that are then read into the dicRow dictionary.
    for line in text_file:
        strData = line.split(",")  # reads line into two elements
        dicRow = {"Task":strData[0].strip(),"Priority":strData[1].strip()}
        lstTable.append(dicRow)
    text_file.close()

    while True:
        # 'True' means this will keep executing until the 'break' statement in exit is reached.
        # Step 2: display menu of choices to the user
        Tasklist.show_menu(object)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))

        # Step 3: Method call to display all todo items to the user.
        if strChoice == '1':
            Tasklist.show_contents(lstTable)
            continue

        # Step 4: Method call to add new item to list:
        elif strChoice == '2':
            Tasklist.add_item(strChoice)
            continue

        # Step 5: Method call to remove item from list:
        elif strChoice == '3':
            Tasklist.remove_item(lstTable)
            continue

        # Step 6: Method to save the file to disk.
        elif strChoice == '4':
            Tasklist.save_data(lstTable)
            continue

        else:
            # exit program
            print("Program run complete.\n")
            break

# Run the program
if __name__ == "__main__":
    main()
# program complete
